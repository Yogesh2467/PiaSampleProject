package LnTSample.Project;

import java.awt.Color;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.reflect.Method;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.time.LocalTime;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.TimeUnit;


import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;



import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.remote.MobileCapabilityType;

public class SampleTest {

	static WebElement customerID;
	static WebElement signupButton;
	static WebElement settingButton;

	static Properties prop;
	static AndroidDriver driver;

	public static void main(String[] args) throws MalformedURLException {

		try {

			prop = new Properties();
			FileInputStream is = new FileInputStream(new File("config.properties"));
			prop.load(is);
			System.out.println("Properties file loaded successfully");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

		File appDir = new File("app");
		File apkLocation = new File(appDir, prop.getProperty("APK_NAME"));
		DesiredCapabilities caps = new DesiredCapabilities();
		// caps.setCapability("applicationName", "Redmi 4");
		// caps.setCapability("device", prop.getProperty("device"));
		//caps.setCapability("deviceName", prop.getProperty("deviceName"));
		caps.setCapability("deviceName", "520014eb533186c1");

		caps.setCapability("platformName", prop.getProperty("platformName"));
		caps.setCapability(MobileCapabilityType.NO_RESET, "false");
		if (prop.getProperty("mobileCapability").equals("uiautomator2"))
			caps.setCapability(MobileCapabilityType.AUTOMATION_NAME, prop.getProperty("mobileCapability"));
		caps.setCapability("noReset", true);
		caps.setCapability("fullReset", false);
		caps.setCapability("autoGrantPermissions", true);
		caps.setCapability("noSign", true);
		// caps.setCapability("newCommandTimeout", 3000);
		// caps.setCapability("autoAcceptAlerts", true);
		// caps.setCapability("autoDismissAlerts", true);
		caps.setCapability("autoGrantPermissions", true);
		// caps.setCapability("appActivity","eu.nets.pia.sample.ui.activity.main.MainActivity");

		caps.setCapability("appActivity","eu.nets.pia.sample.ui.activity.LoginActivity");
		caps.setCapability("appPackage","eu.nets.pia.sample");

		// other caps        

		caps.setCapability("app", apkLocation.getAbsolutePath());
		String appiumURL = prop.getProperty("appiumURL");
		driver = new AndroidDriver(new URL(appiumURL), caps);

		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		customerID=driver.findElement(By.id("eu.nets.pia.sample:id/customer_id_et"));
		customerID.clear();
		customerID.sendKeys("01010");

		signupButton=driver.findElement(By.id("eu.nets.pia.sample:id/sign_up_btn"));

		signupButton.click();

		settingButton=driver.findElement(By.id("eu.nets.pia.sample:id/settings_item"));

		settingButton.click();
	}
}




